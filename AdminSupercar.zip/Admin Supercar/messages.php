<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: Index.php");
    exit();
}

// Connexion à la base
$pdo = new PDO('mysql:host=localhost;dbname=supercar;charset=utf8', 'root', '');

// Récupérer les messages complets
$messages = $pdo->query("SELECT idclient, nom, email, sujet, message FROM contactez ORDER BY idclient DESC")->fetchAll(PDO::FETCH_ASSOC);
$current_page = basename($_SERVER['PHP_SELF']);

?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Messages - Admin</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6f9;
      margin: 0;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    .navbar {
      background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
      padding: 1rem 2rem;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .navbar-brand {
      font-weight: bold;
      color: #fff !important;
      display: flex;
      align-items: center;
    }

    .nav-link {
      color: white !important;
      font-weight: 500;
      margin-left: 1rem;
      transition: all 0.3s;
    }

    .nav-link.active {
      color: #0d6efd !important;
      font-weight: bold;
      border-bottom: 2px solid #0d6efd;
    }

    .nav-link:hover {
      color: #0d6efd !important;
    }

    .content {
      flex: 1;
      padding-top: 80px;
      padding-bottom: 60px;
      overflow-y: auto;
      height: calc(100vh - 140px);
    }

    .card {
      border: none;
      box-shadow: 0 4px 8px rgba(0,0,0,0.05);
      border-left: 4px solid #12906c;
      transition: all 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .table th, .table td {
      vertical-align: middle;
    }

    footer {
      background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
      color: white;
      padding: 1.5rem 0;
      text-align: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      position: fixed;
      bottom: 0;
      width: 100%;
      box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
    }

    .nav-menu {
      display: flex;
      justify-content: center;
      flex-grow: 1;
    }

    .user-info {
      text-align: right;
    }
  </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg">
      <div class="navbar-brand text-white fw-bold">SuperCar - Admin</div>
      <div class="nav-menu d-flex justify-content-center flex-grow-1">
        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item px-2">
            <a href="Index.php" class="nav-link text-white acitve"
              >Dashboard</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="Gestion_utilisateur.php" class="nav-link text-white"
              >Utilisateurs</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="voitures.php" class="nav-link text-white">Voitures</a>
          </li>
          <li class="nav-item px-2">
            <a href="Demande.php" class="nav-link text-white"
              >Demande d'essai</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="messages.php" class="nav-link text-white"
              >Messages & Contacts</a
            >
          </li>
        </ul>
      </div>
      <div class="user-info">
        <div class="fw-bold">
          <?php
                $email = $_SESSION['admin'] ?? 'admin@example.com';
                $username = explode('@', $email)[0];
                echo htmlspecialchars($username);
                ?>
        </div>
        <a href="logout.php" class="text-white" style="font-size: 0.85rem"
          ><i class="fas fa-sign-out-alt"></i> Déconnexion</a
        >
      </div>
    </nav>

<!-- Contenu -->
<div class="content container mt-4">
  <h2 class="text-center"><i class="fas fa-envelope"></i> Boîte de réception</h2>
  <div class="card p-3 mt-3">
    <table class="table table-hover">
      <thead class="table-dark text-center">
        <tr>
          <th>ID</th>      
          <th>Sujet</th>
          <th>Email</th>
          <th>Message</th>
          
          
        </tr>
      </thead>
      <tbody>
        <?php foreach ($messages as $msg): ?>
          <tr>

            <td class="text-center"><?= $msg['idclient'] ?></td>
            <td><?= htmlspecialchars($msg['sujet']) ?></td>
            <td><?= htmlspecialchars($msg['email']) ?></td>
            <td><?= htmlspecialchars(($msg['message'])) ?></td>
           
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Footer -->
<footer>
  <p style="margin: 0; font-size: 1.1rem; letter-spacing: 1px; font-weight: bold;">
    © SUPERCAR 2024-2026 | Admin MCCI | SIO
  </p>
</footer>
</body>
</html>