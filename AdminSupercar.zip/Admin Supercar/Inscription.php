<?php
session_start();
$erreur = "";
$succes = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $mdp = $_POST["motdepasse"];
    $confirmation_mdp = $_POST["confirmation_motdepasse"];

    // Vérification que les mots de passe correspondent
    if ($mdp !== $confirmation_mdp) {
        $erreur = "Les mots de passe ne correspondent pas.";
    } else {
        // Connexion à la base de données 'supercar'
        $connexion = new mysqli("localhost", "root", "", "supercar");

        if ($connexion->connect_error) {
            die("Connexion échouée : " . $connexion->connect_error);
        }

        // Vérification si l'email existe déjà dans la table 'admin'
        $stmt = $connexion->prepare("SELECT * FROM admin WHERE username = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $resultat = $stmt->get_result();

        if ($resultat->num_rows > 0) {
            $erreur = "Cet email est déjà utilisé.";
        } else {
            // Hachage du mot de passe
            $motdepasse_hache = password_hash($mdp, PASSWORD_BCRYPT);

            // Insertion dans la table 'admin' de la base 'supercar'
            $stmt = $connexion->prepare("INSERT INTO admin (username, password) VALUES (?, ?)");
            $stmt->bind_param("ss", $email, $motdepasse_hache);

            if ($stmt->execute()) {
                $succes = "Compte créé avec succès. Vous pouvez maintenant vous connecter.";
            } else {
                $erreur = "Une erreur est survenue lors de la création du compte.";
            }
        }

        $stmt->close();
        $connexion->close();
    }
}
?>

<!-- ... Code PHP inchangé ... -->

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Créer un compte Admin - SuperCar</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {
      margin: 0;
      height: 100vh;
      background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .register-box {
      background-color: white;
      padding: 3rem;
      border-radius: 1rem;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
      width: 100%;
      max-width: 400px;
    }
    .btn-primary {
      background-color: #12906c;
      border: none;
    }
    .btn-primary:hover {
      background-color: #0f7f5c;
    }
  </style>
</head>
<body>

<div class="register-box">
  <h2 class="text-center mb-4">S'inscrire</h2>
  
  <?php if ($erreur): ?>
    <div class="alert alert-danger"><?= $erreur ?></div>
  <?php endif; ?>
  <?php if ($succes): ?>
    <div class="alert alert-success"><?= $succes ?></div>
  <?php endif; ?>
  
  <form method="POST" action="">
    <div class="mb-3">
      <label>Email</label>
      <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Mot de passe</label>
      <input type="password" id="motdepasse" name="motdepasse" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Confirmer le mot de passe</label>
      <input type="password" id="confirmation_motdepasse" name="confirmation_motdepasse" class="form-control" required>
    </div>

    <div class="form-check mb-3">
      <input class="form-check-input" type="checkbox" id="voirMdp" onclick="afficherMdp()">
      <label class="form-check-label" for="voirMdp">
        Afficher les mots de passe
      </label>
    </div>

    <div class="d-grid mb-2">
      <button type="submit" class="btn btn-primary">Créer un compte</button>
    </div>
    <div class="text-center">
      <a href="log">Déjà un compte ? Connectez-vous</a>
    </div>
  </form>
</div>

<script>
function afficherMdp() {
  const mdp = document.getElementById("motdepasse");
  const confirmation = document.getElementById("confirmation_motdepasse");
  const type = mdp.type === "password" ? "text" : "password";
  mdp.type = type;
  confirmation.type = type;
}
</script>

</body>
</html>
