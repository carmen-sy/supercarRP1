<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $marque = filter_input(INPUT_POST, 'marque');
        $modele = filter_input(INPUT_POST, 'modele');
        $prix = filter_input(INPUT_POST, 'prix');
        $photo = filter_input(INPUT_POST, 'photo');
        $categorie = filter_input(INPUT_POST, 'categorie');
        $description = filter_input(INPUT_POST, 'description');
        $transmission = filter_input(INPUT_POST, 'transmission');
        $disponible = isset($_POST['disponible']) ? 1 : 0;

        if ($modele && $prix !== false) {
            $sql = "INSERT INTO voiture (marque, modele, prix, photo, categorie, description, transmission, disponible) 
                    VALUES (:marque, :modele, :prix, :photo, :categorie, :description, :transmission, :disponible)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':marque' => $marque,
                ':modele' => $modele,
                ':prix' => $prix,
                ':photo' => $photo ?: null,
                ':categorie' => $categorie ?: null,
                ':description' => $description ?: null,
                ':transmission' => $transmission ?: null,
                ':disponible' => $disponible
            ]);
        }
    }
} catch(PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}

$conn = null;
header("Location: voitures.php");
exit;
?>