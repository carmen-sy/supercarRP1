<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: Index.php");
    exit();
}

// Connexion à la base
$pdo = new PDO('mysql:host=localhost;dbname=supercar', 'root', '');

// Vérification de l'ID utilisateur
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: Index.php");
    exit();
}

$id = (int) $_GET['id'];

// Si le formulaire est soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom = $_POST['nom'] ?? '';
    $prenom = $_POST['prenom'] ?? '';
    $email = $_POST['email'] ?? '';
    $ville = $_POST['ville'] ?? '';

    $stmt = $pdo->prepare("UPDATE inscription SET nom=?, prenom=?, email=?, ville=? WHERE id=?");
    $stmt->execute([$nom, $prenom, $email, $ville, $id]);

    // Redirection vers le tableau de bord avec message
    header("Location: Gestion_utilisateur.php?message=modification");
    exit();
}

// Récupération des infos utilisateur
$stmt = $pdo->prepare("SELECT * FROM inscription WHERE id=?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header("Location: Index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Modifier Utilisateur</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
  <h2 class="text-center mb-4">Modifier l'utilisateur</h2>

  <form method="post" class="bg-white p-4 rounded shadow-sm">
    <div class="mb-3">
      <label class="form-label">Nom</label>
      <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($user['nom']) ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Prénom</label>
      <input type="text" name="prenom" class="form-control" value="<?= htmlspecialchars($user['prenom']) ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Email</label>
      <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label">Ville</label>
      <input type="text" name="ville" class="form-control" value="<?= htmlspecialchars($user['ville']) ?>">
    </div>

    <div class="d-flex justify-content-between">
      <a href="Gestion_Utilisateur.php" class="btn btn-secondary">Annuler</a>
      <button type="submit" class="btn btn-primary">Enregistrer</button>
    </div>
  </form>
</div>
</body>
</html>
