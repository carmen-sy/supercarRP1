<?php
session_start();

// Vérification de la session admin
if (!isset($_SESSION['admin'])) {
    header("Location: Index.php");
    exit();
}

// Connexion à la base de données
try {
    $pdo = new PDO('mysql:host=localhost;dbname=supercar;charset=utf8', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Gestion de la suppression
if (isset($_GET['delete'])) {
    $id = (int) $_GET['delete'];
    $pdo->prepare("DELETE FROM inscription WHERE id = ?")->execute([$id]);
    header("Location: Gestion_utilisateur.php?message=suppression");
    exit();
}

// Gestion du changement de mot de passe
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $user_id = (int) $_POST['user_id'];
    $new_password = $_POST['new_password'];
    
    // Validation du mot de passe
    if (strlen($new_password) < 6) {
        $error = "Le mot de passe doit contenir au moins 6 caractères.";
    } else {
        // Hachage du mot de passe
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE inscription SET password = ? WHERE id = ?");
        if ($stmt->execute([$hashed_password, $user_id])) {
            $success = "Mot de passe mis à jour avec succès.";
        } else {
            $error = "Erreur lors de la mise à jour du mot de passe.";
        }
    }
}

// Récupération des inscriptions
$stmt = $pdo->query("SELECT * FROM inscription ORDER BY id DESC");
$inscriptions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Utilisateurs - Admin</title>

    <!-- Bootstrap & Font Awesome (CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .navbar {
            background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
            padding: 0.85rem 1.5rem;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 999;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        main.content {
            padding-top: 100px;
            padding-bottom: 80px;
            flex: 1;
        }
        footer {
            background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
            color: white;
            text-align: center;
            padding: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
        }
        .user-info {
            text-align: right;
            color: #fff;
        }
        .table-hover tbody tr:hover {
            cursor: pointer;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="navbar-brand text-white fw-bold">SuperCar - Admin</div>
        <div class="nav-menu d-flex justify-content-center flex-grow-1">
            <ul class="navbar-nav d-flex flex-row">
                <li class="nav-item px-2">
                    <a href="Index.php" class="nav-link text-white">Dashboard</a>
                </li>
                <li class="nav-item px-2">
                    <a href="Gestion_utilisateur.php" class="nav-link text-white">Utilisateurs</a>
                </li>
                <li class="nav-item px-2">
                    <a href="voitures.php" class="nav-link text-white">Voitures</a>
                </li>
                <li class="nav-item px-2">
                    <a href="Demande.php" class="nav-link text-white">Demande d'essai</a>
                </li>
                <li class="nav-item px-2">
                    <a href="messages.php" class="nav-link text-white">Messages & Contacts</a>
                </li>
            </ul>
        </div>
        <div class="user-info">
            <div class="fw-bold">
                <?php
                $email = $_SESSION['admin'] ?? 'admin@example.com';
                $username = explode('@', $email)[0];
                echo htmlspecialchars($username);
                ?>
            </div>
            <a href="logout.php" class="text-white" style="font-size:0.85rem;"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
        </div>
    </nav>

    <!-- Contenu principal -->
    <main class="content container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h4 mb-0">Gestion des utilisateurs</h1>

            <!-- Message de suppression ou de changement de mot de passe -->
            <?php if (isset($_GET['message']) && $_GET['message'] === 'suppression'): ?>
                <div id="alertSuppression" class="alert alert-success mb-0 py-1 px-2">
                    Utilisateur supprimé.
                </div>
            <?php elseif (isset($success)): ?>
                <div id="alertSuccess" class="alert alert-success mb-0 py-1 px-2">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php elseif (isset($error)): ?>
                <div id="alertError" class="alert alert-danger mb-0 py-1 px-2">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
        </div>



        <!-- Tableau des utilisateurs -->
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-bordered table-hover mb-0" id="userTable">
                    <thead class="table-dark">
                        <tr>
                            <th style="width:80px">ID</th>
                            <th>Nom</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($inscriptions as $user): ?>
                            <tr data-user='<?= json_encode($user, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>'>
                                <td><?= htmlspecialchars($user['id'] ?? '') ?></td>
                                <td><?= htmlspecialchars($user['nom'] ?? '') ?></td>
                                <td><?= htmlspecialchars($user['email'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>



    <!-- Modal détails utilisateur -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Détails de l'utilisateur</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <ul class="list-group">
                                <li class="list-group-item"><strong>ID :</strong> <span id="modalId"></span></li>
                                <li class="list-group-item"><strong>Nom :</strong> <span id="modalNom"></span></li>
                                <li class="list-group-item"><strong>Prénom :</strong> <span id="modalPrenom"></span></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-group">
                                <li class="list-group-item"><strong>Email :</strong> <span id="modalEmail"></span></li>
                                <li class="list-group-item"><strong>Ville :</strong> <span id="modalVille"></span></li>
                                <li class="list-group-item"><strong>Date d'inscription :</strong> <span id="modalDate"></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" id="btnEdit" class="btn btn-warning"><i class="fas fa-edit me-1"></i> Modifier</a>
                    <button id="btnPassword" class="btn btn-info text-white" data-bs-toggle="modal" data-bs-target="#passwordModal"><i class="fas fa-key me-1"></i> Changer mot de passe</button>
                    <button id="btnDelete" class="btn btn-danger"><i class="fas fa-trash me-1"></i> Supprimer</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal changement mot de passe -->
<div class="modal fade" id="passwordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <form method="POST" action="">
                <div class="modal-header">
                    <h5 class="modal-title">Changer le mot de passe</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="user_id" id="passwordUserId">
                    <div class="mb-3 position-relative">
                        <label for="new_password" class="form-label">Nouveau mot de passe</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="6">
                        <span class="position-absolute end-0 translate-middle-y me-3" id="togglePassword" style="cursor: pointer; top: calc(65% + 5px);">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="change_password" class="btn btn-primary">Enregistrer</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                </div>
            </form>
        </div>
    </div>
</div>

    <!-- Footer -->
    <footer>
        © SUPERCAR 2024-2026 | Admin MCCI | SIO
    </footer>

    <!-- Script JavaScript -->
    <script>
        (function () {
            const rows = document.querySelectorAll("#userTable tbody tr");
            const bsModalEl = document.getElementById("userModal");
            const userModal = new bootstrap.Modal(bsModalEl);
            const modalId = document.getElementById("modalId");
            const modalNom = document.getElementById("modalNom");
            const modalPrenom = document.getElementById("modalPrenom");
            const modalEmail = document.getElementById("modalEmail");
            const modalVille = document.getElementById("modalVille");
            const modalDate = document.getElementById("modalDate");
            const btnEdit = document.getElementById("btnEdit");
            const btnDelete = document.getElementById("btnDelete");
            const btnPassword = document.getElementById("btnPassword");
            const passwordUserId = document.getElementById("passwordUserId");

            let currentUserId = null;

            rows.forEach(row => {
                row.addEventListener("click", () => {
                    const user = JSON.parse(row.getAttribute('data-user') || '{}');
                    currentUserId = user.id ?? null;
                    modalId.textContent = user.id ?? '';
                    modalNom.textContent = user.nom ?? '';
                    modalPrenom.textContent = user.prenom ?? '';
                    modalEmail.textContent = user.email ?? '';
                    modalVille.textContent = user.ville ?? '';
                    modalDate.textContent = user.date_inscription ?? '';
                    btnEdit.setAttribute('href', 'Edit_user.php?id=' + encodeURIComponent(user.id));
                    passwordUserId.value = user.id ?? '';
                    userModal.show();
                });
            });

            // Suppression avec confirmation
            btnDelete.addEventListener('click', function () {
                if (!currentUserId) return;
                if (confirm("Confirmer la suppression de l'utilisateur #" + currentUserId + " ?")) {
                    window.location.href = '?delete=' + encodeURIComponent(currentUserId);
                }
            });
        })();

        // Gestion des messages temporaires
        const alertSupp = document.getElementById("alertSuppression");
        const alertSuccess = document.getElementById("alertSuccess");
        const alertError = document.getElementById("alertError");
        [alertSupp, alertSuccess, alertError].forEach(alert => {
            if (alert) {
                setTimeout(() => {
                    alert.style.display = "none";
                }, 3000); // 3 secondes
            }
        });


        // Gestion de l'affichage/masquage du mot de passe
const togglePassword = document.getElementById('togglePassword');
const passwordInput = document.getElementById('new_password');

togglePassword.addEventListener('click', function () {
    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordInput.setAttribute('type', type);


    // Changer l'icône entre œil ouvert et œil barré
    this.querySelector('i').classList.toggle('fa-eye');
    this.querySelector('i').classList.toggle('fa-eye-slash');
});


    </script>



</body>
</html>