<?php
session_start();

// Vérification de la session admin
if (!isset($_SESSION['admin'])) {
    header("Location: log.php");
    exit();
}

// Connexion à la base de données
try {
    $pdo = new PDO('mysql:host=localhost;dbname=supercar;charset=utf8', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    die("Erreur : " . $e->getMessage());
}

// Compter les clients inscrits (table inscription)
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM inscription");
$stmt->execute();
$clients_inscrits = $stmt->fetch()['total'] ?? 0;

// Compter toutes les réservations enregistrées (table essai, sans filtre)
$reservations_totales = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(DISTINCT id) as total FROM essai");
    $stmt->execute();
    $reservations_totales = $stmt->fetch()['total'] ?? 0;
} catch (PDOException $e) {
    error_log("Erreur : " . $e->getMessage());
    $reservations_totales = 0; // Valeur par défaut si erreur
}

//Compter le nombre de voitures
try {
 $stmt = $pdo->prepare("SELECT COUNT(DISTINCT id) as total FROM voiture");
 $stmt->execute();
 $nombre_voitures = $stmt->fetch()['total'] ?? 0;
} catch(PDOException $e) {
    echo "Erreur : " . $e->getMessage();
    $nombre_voitures = 0; // Valeur par défaut en cas d'erreur
}

// Fermeture de la connexion
$conn = null;


// Récupérer les statistiques de "connexions" (groupées par date d'inscription)
$stmt = $pdo->prepare("
    SELECT 
        DATE(date_inscription) AS jour,
        COUNT(*) AS nb_connexions,
        LAG(COUNT(*), 1) OVER (ORDER BY DATE(date_inscription)) AS prev_count,
        CASE 
            WHEN LAG(COUNT(*), 1) OVER (ORDER BY DATE(date_inscription)) IS NULL THEN 0
            ELSE COUNT(*) - LAG(COUNT(*), 1) OVER (ORDER BY DATE(date_inscription))
        END AS difference
    FROM inscription
    GROUP BY DATE(date_inscription)
    ORDER BY jour DESC
    LIMIT 10
");
$stmt->execute();
$stats_connexions = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Admin</title>
    <!-- Bootstrap & Font Awesome (CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Chart.js pour le graphique en barres -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            margin: 0;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .navbar {
            background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
            padding: 0.85rem 1.5rem;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 999;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        main.content {
            padding-top: 100px;
            padding-bottom: 80px;
            flex: 1;
        }
        footer {
            background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
            color: white;
            text-align: center;
            padding: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
        }
        .user-info {
            text-align: right;
            color: #fff;
        }
        .stat-card {
            background: linear-gradient(135deg, #021638, #12906c);
            color: white;
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0,0,0,0.2);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .stat-chart {
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 1rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="navbar-brand text-white fw-bold">SuperCar - Admin</div>
        <div class="nav-menu d-flex justify-content-center flex-grow-1">
            <ul class="navbar-nav d-flex flex-row">
                <li class="nav-item px-2">
                    <a href="Index.php" class="nav-link text-white acitve">Dashboard</a>
                </li>
                <li class="nav-item px-2">
                    <a href="Gestion_utilisateur.php" class="nav-link text-white">Utilisateurs</a>
                </li>
                <li class="nav-item px-2">
                    <a href="voitures.php" class="nav-link text-white">Voitures</a>
                </li>
                <li class="nav-item px-2">
                    <a href="Demande.php" class="nav-link text-white">Demande D'Essai</a>
                </li>
                <li class="nav-item px-2">
                    <a href="messages.php" class="nav-link text-white">Messages & Contacts</a>
                </li>
            </ul>
        </div>
        <div class="user-info">
            <div class="fw-bold">
                <?php
                $email = $_SESSION['admin'] ?? 'admin@example.com';
                $username = explode('@', $email)[0];
                echo htmlspecialchars($username);
                ?>
            </div>
            <a href="logout.php" class="text-white" style="font-size:0.85rem;"><i class="fas fa-sign-out-alt"></i> Déconnexion</a>
        </div>
    </nav>

    <!-- Contenu principal -->
<main class="content container">
    <div class="row mb-4">
        <div class="col-12">
            <h1 class="h4 mb-0">Tableau de Bord</h1>
        </div>
    </div>

    <!-- Cartes de statistiques rapides -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="stat-card" id="clientsCard">
                <i class="fas fa-users fa-3x mb-3"></i>
                <div class="stat-number"><?php echo $clients_inscrits; ?></div>
                <div>Clients inscrits</div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stat-card" id="reservationsCard">
                <i class="fas fa-calendar-check fa-3x mb-3"></i>
                <div class="stat-number"><?php echo $reservations_totales; ?></div>
                <div>Réservations enregistrées</div>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="stat-card" id="reservationsCard">
                <i class="fa-solid fa-car fa-3x mb-3"></i>
                <div class="stat-number"><?php echo $nombre_voitures; ?></div>
                <div>Voitures enregistrées</div>
            </div>
        </div>
    </div>

    <!-- Schéma de statistiques en bâtonnets -->
    <div class="row">
        <div class="col-12">
            <div class="card stat-chart">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0"><i class="fas fa-chart-bar me-2"></i>Statistiques des connexions clients (par date d'inscription)</h5>
                </div>
                <div class="card-body">
                    <canvas id="statsChart" height="200"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Message d'avertissement si erreur -->
    <?php if ($reservations_totales === 0 && isset($e)): ?>
        <div class="alert alert-warning mt-4">
            Aucune donnée de réservations disponible (erreur lors du comptage).
        </div>
    <?php endif; ?>
</main>

    <!-- Footer -->
    <footer>
        © SUPERCAR 2024-2026 | Admin MCCI | SIO
    </footer>

    <!-- Script JavaScript -->
    <script>
        // Effet hover déjà géré par CSS

        // Double-clic sur les cartes pour rediriger
        document.getElementById('clientsCard').addEventListener('dblclick', function() {
            window.location.href = 'Gestion_utilisateur.php';
        });

        document.getElementById('reservationsCard').addEventListener('dblclick', function() {
            window.location.href = 'Demande.php';
        });

        // Données pour le graphique en barres
const statsData = <?php echo json_encode($stats_connexions); ?>;

// Labels = jours, Données = connexions
const labels = statsData.map(item => item.jour || 'N/A');
const data = statsData.map(item => item.nb_connexions || 0);

// Création du graphique
const ctx = document.getElementById('statsChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: labels,
        datasets: [{
            label: 'Nombre de connexions par jour',
            data: data,
            backgroundColor: 'rgba(18, 144, 108, 0.6)',
            borderColor: 'rgba(18, 144, 108, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            x: {
                title: { display: true, text: 'Jour' }
            },
            y: {
                beginAtZero: true,
                title: { display: true, text: 'Connexions' }
            }
        },
        responsive: true,
        maintainAspectRatio: false
    }
});

    </script>
</body>
</html>