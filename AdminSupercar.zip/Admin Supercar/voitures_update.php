<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = (int) $_POST['id'];
        $modele = trim($_POST['modele']);
        $prix = (float) $_POST['prix'];
        $photo = trim($_POST['photo']);
        $categorie = trim($_POST['categorie']);
        $description = trim($_POST['description']);
        $transmission = trim($_POST['transmission']);
        $disponible = isset($_POST['disponible']) ? 1 : 0;

        $sql = "UPDATE voiture SET 
                    modele = :modele,
                    prix = :prix,
                    photo = :photo,
                    categorie = :categorie,
                    description = :description,
                    transmission = :transmission,
                    disponible = :disponible
                WHERE id = :id";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ':modele' => $modele,
            ':prix' => $prix,
            ':photo' => $photo ?: null,
            ':categorie' => $categorie ?: null,
            ':description' => $description ?: null,
            ':transmission' => $transmission ?: null,
            ':disponible' => $disponible,
            ':id' => $id
        ]);
    }
} catch(PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}

header("Location: voitures.php");
exit;
?>