<?php
// logout.php
session_start();

// Supprimer toutes les données de session
$_SESSION = [];
session_destroy();

// Rediriger vers la page de connexion
header("Location: log.php");
exit;
?>
