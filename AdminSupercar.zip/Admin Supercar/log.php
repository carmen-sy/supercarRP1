<?php
session_start();
$erreur = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $mdp = $_POST["motdepasse"];

    // Connexion à la base de données
    $connexion = new mysqli("localhost", "root", "", "supercar");

    if ($connexion->connect_error) {
        die("Connexion échouée : " . $connexion->connect_error);
    }

    // Préparation de la requête
    $stmt = $connexion->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultat = $stmt->get_result();

    if ($resultat->num_rows === 1) {
        $utilisateur = $resultat->fetch_assoc();
        if (password_verify($mdp, $utilisateur["password"])) {
            $_SESSION["admin"] = $email;
            header("Location: Index.php");
            exit();
        }
    }

    $erreur = "Identifiants incorrects.";

    $stmt->close();
    $connexion->close();
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Connexion Admin - SuperCar</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {
      margin: 0;
      height: 100vh;
      background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .login-box {
      background-color: white;
      padding: 3rem;
      border-radius: 1rem;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
      width: 100%;
      max-width: 400px;
    }
    .btn-primary {
      background-color: #12906c;
      border: none;
    }
    .btn-primary:hover {
      background-color: #0f7f5c;
    }
  </style>
</head>
<body>

<div class="login-box">
  <h2 class="text-center mb-4">Connexion Admin</h2>
  <?php if ($erreur): ?>
    <div class="alert alert-danger"><?= $erreur ?></div>
  <?php endif; ?>
  <form method="POST" action="">
    <div class="mb-3">
      <label>Email</label>
      <input type="username" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
      <label>Mot de passe</label>
      <input type="password" name="motdepasse" class="form-control" required>
    </div>
    <div class="d-grid mb-2">
      <button type="submit" class="btn btn-primary">Se connecter</button>
    </div>
    <div class="text-center">
      <a href="Inscription.php">Pas encore inscrit ? Créez un compte</a>
    </div>
  </form>
</div>

</body>
</html>