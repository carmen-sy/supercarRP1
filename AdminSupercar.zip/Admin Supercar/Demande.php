<?php
session_start();

// Vérification de la session admin
if (!isset($_SESSION['admin'])) {
    header("Location: Index.php");
    exit();
}

// Connexion à la base de données avec PDO
try {
    $pdo = new PDO('mysql:host=localhost;dbname=supercar;charset=utf8', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (Exception $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}

// Gestion de la recherche
$search = "";
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $like = "%$search%";
    $stmt = $pdo->prepare("SELECT * FROM essai WHERE nom LIKE ? OR email LIKE ?");
    $stmt->execute([$like, $like]);
    $essais = $stmt->fetchAll();
} else {
    $stmt = $pdo->query("SELECT * FROM essai ORDER BY id DESC");
    $essais = $stmt->fetchAll();
}

// Gestion de la modification
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_essai'])) {
    $id = filter_var($_POST['id'], FILTER_VALIDATE_INT);
    $lieurecup = trim($_POST['lieurecup']);
    $lieudepot = trim($_POST['lieudepot']);
    $daterecup = trim($_POST['daterecup']);
    $datedepot = trim($_POST['datedepot']);
    $heurerrecup = trim($_POST['heurerrecup']);

    if ($id !== false) {
        $stmt = $pdo->prepare("UPDATE essai SET lieurecup = ?, lieudepot = ?, daterecup = ?, datedepot = ?, heurerrecup = ? WHERE id = ?");
        if ($stmt->execute([$lieurecup, $lieudepot, $daterecup, $datedepot, $heurerrecup, $id])) {
            $message = ['type' => 'success', 'text' => 'Demande mise à jour avec succès.'];
        } else {
            $message = ['type' => 'danger', 'text' => 'Erreur lors de la mise à jour de la demande.'];
        }
    } else {
        $message = ['type' => 'danger', 'text' => 'ID invalide.'];
    }
}

// Gestion de la suppression
if (isset($_GET['delete'])) {
    $id = filter_var($_GET['delete'], FILTER_VALIDATE_INT);
    if ($id !== false) {
        $stmt = $pdo->prepare("DELETE FROM essai WHERE id = ?");
        $stmt->execute([$id]);
        header("Location: Demande.php?message=suppression");
        exit();
    }
}

// Gestion du message de suppression
if (isset($_GET['message']) && $_GET['message'] === 'suppression') {
    $message = ['type' => 'success', 'text' => 'Demande supprimée avec succès.'];
}

// Récupérer la page actuelle
$current_page = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essais - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            margin: 0;
        }
        .navbar {
            background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
            padding: 0.85rem 1.5rem;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
        .navbar-brand {
            font-weight: bold;
            color: #fff !important;
        }
        .nav-link {
            color: white !important;
            font-weight: 500;
            margin: 0 1rem;
            transition: all 0.3s;
        }
        .nav-link.active {
            color: #0d6efd !important;
            border-bottom: 2px solid #0d6efd;
        }
        .nav-link:hover {
            color: #0d6efd !important;
        }
        .content {
            padding-top: 100px;
            padding-bottom: 80px;
            flex: 1;
        }
        .card {
            border: none;
            border-left: 4px solid #12906c;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
            transition: transform 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .table th, .table td {
            vertical-align: middle;
        }
        footer {
            background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
            color: white;
            text-align: center;
            padding: 0.9rem;
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
        }
        .user-info {
            text-align: right;
            color: #fff;
        }
        .table-hover tbody tr:hover {
            cursor: pointer;
            background-color: #e9ecef;
        }
        .alert {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 1000;
            padding: 0.75rem 1.25rem;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
<nav class="navbar navbar-expand-lg">
      <div class="navbar-brand text-white fw-bold">SuperCar - Admin</div>
      <div class="nav-menu d-flex justify-content-center flex-grow-1">
        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item px-2">
            <a href="Index.php" class="nav-link text-white acitve"
              >Dashboard</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="Gestion_utilisateur.php" class="nav-link text-white"
              >Utilisateurs</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="voitures.php" class="nav-link text-white">Voitures</a>
          </li>
          <li class="nav-item px-2">
            <a href="Demande.php" class="nav-link text-white"
              >Demande d'essai</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="messages.php" class="nav-link text-white"
              >Messages & Contacts</a
            >
          </li>
        </ul>
      </div>
      <div class="user-info">
        <div class="fw-bold">
          <?php
                $email = $_SESSION['admin'] ?? 'admin@example.com';
                $username = explode('@', $email)[0];
                echo htmlspecialchars($username);
                ?>
        </div>
        <a href="logout.php" class="text-white" style="font-size: 0.85rem"
          ><i class="fas fa-sign-out-alt"></i> Déconnexion</a
        >
      </div>
    </nav>

    <!-- Contenu principal -->
    <main class="content container">
        <h1 class="h4 mb-4">Gestion des demandes d'essai</h1>

        <!-- Affichage des messages -->
        <?php if (!empty($message)): ?>
            <div class="alert alert-<?= htmlspecialchars($message['type']) ?> alert-dismissible fade show">
                <?= htmlspecialchars($message['text']) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Formulaire de recherche -->
        <form method="GET" class="mb-4 d-flex">
            <input type="text" name="search" class="form-control me-2" placeholder="Rechercher par nom ou email" value="<?= htmlspecialchars($search) ?>">
            <button type="submit" class="btn btn-primary">Rechercher</button>
        </form>

        <!-- Tableau des demandes -->
        <div class="card shadow-sm">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover mb-0" id="essaiTable">
                        <thead class="table-dark">
                            <tr>
                                <th style="width:80px">ID</th>
                                <th>Nom</th>
                                <th>Email</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($essais) > 0): ?>
                                <?php foreach ($essais as $row): ?>
                                    <tr data-essai='<?= json_encode($row, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>'>
                                        <td><?= htmlspecialchars($row['id'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($row['nom'] ?? '') ?></td>
                                        <td><?= htmlspecialchars($row['email'] ?? '') ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="3" class="text-center">Aucune demande trouvée</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal détails de la demande -->
    <div class="modal fade" id="essaiModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Détails de la demande</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <ul class="list-group">
                                <li class="list-group-item"><strong>ID :</strong> <span id="modalId"></span></li>
                                <li class="list-group-item"><strong>Nom :</strong> <span id="modalNom"></span></li>
                                <li class="list-group-item"><strong>Prénom :</strong> <span id="modalPrenom"></span></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul class="list-group">
                                <li class="list-group-item"><strong>Email :</strong> <span id="modalEmail"></span></li>
                                <li class="list-group-item"><strong>Lieu récupération :</strong> <span id="modalLieurecup"></span></li>
                                <li class="list-group-item"><strong>Lieu dépôt :</strong> <span id="modalLieudepot"></span></li>
                            </ul>
                        </div>
                        <div class="col-12">
                            <ul class="list-group">
                                <li class="list-group-item"><strong>Date récupération :</strong> <span id="modalDaterecup"></span></li>
                                <li class="list-group-item"><strong>Date dépôt :</strong> <span id="modalDatedepot"></span></li>
                                <li class="list-group-item"><strong>Heure récupération :</strong> <span id="modalHeurerrecup"></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="btnEdit" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editModal"><i class="fas fa-edit me-1"></i> Modifier</button>
                    <button id="btnDelete" class="btn btn-danger"><i class="fas fa-trash me-1"></i> Supprimer</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal modification -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <form method="POST" action="">
                    <div class="modal-header">
                        <h5 class="modal-title">Modifier la demande</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="editId">
                        <div class="mb-3">
                            <label for="editLieurecup" class="form-label">Lieu récupération</label>
                            <input type="text" class="form-control" id="editLieurecup" name="lieurecup" required>
                        </div>
                        <div class="mb-3">
                            <label for="editLieudepot" class="form-label">Lieu dépôt</label>
                            <input type="text" class="form-control" id="editLieudepot" name="lieudepot" required>
                        </div>
                        <div class="mb-3">
                            <label for="editDaterecup" class="form-label">Date récupération</label>
                            <input type="date" class="form-control" id="editDaterecup" name="daterecup" required>
                        </div>
                        <div class="mb-3">
                            <label for="editDatedepot" class="form-label">Date dépôt</label>
                            <input type="date" class="form-control" id="editDatedepot" name="datedepot" required>
                        </div>
                        <div class="mb-3">
                            <label for="editHeurerrecup" class="form-label">Heure récupération</label>
                            <input type="time" class="form-control" id="editHeurerrecup" name="heurerrecup" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="update_essai" class="btn btn-primary">Enregistrer</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer>
        © SUPERCAR <?= date("Y") ?>-2026 | Admin MCCI | SIO
    </footer>

    <!-- Script JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const essaiTable = document.getElementById('essaiTable');
            const essaiModalEl = document.getElementById('essaiModal');
            const essaiModal = new bootstrap.Modal(essaiModalEl);
            const modalId = document.getElementById('modalId');
            const modalNom = document.getElementById('modalNom');
            const modalPrenom = document.getElementById('modalPrenom');
            const modalEmail = document.getElementById('modalEmail');
            const modalLieurecup = document.getElementById('modalLieurecup');
            const modalLieudepot = document.getElementById('modalLieudepot');
            const modalDaterecup = document.getElementById('modalDaterecup');
            const modalDatedepot = document.getElementById('modalDatedepot');
            const modalHeurerrecup = document.getElementById('modalHeurerrecup');
            const btnEdit = document.getElementById('btnEdit');
            const btnDelete = document.getElementById('btnDelete');
            const editId = document.getElementById('editId');
            const editLieurecup = document.getElementById('editLieurecup');
            const editLieudepot = document.getElementById('editLieudepot');
            const editDaterecup = document.getElementById('editDaterecup');
            const editDatedepot = document.getElementById('editDatedepot');
            const editHeurerrecup = document.getElementById('editHeurerrecup');

            let currentEssaiId = null;

            // Gestion du clic sur une ligne du tableau
            essaiTable.querySelectorAll('tbody tr').forEach(row => {
                row.addEventListener('click', () => {
                    const essai = JSON.parse(row.getAttribute('data-essai') || '{}');
                    currentEssaiId = essai.id ?? null;
                    modalId.textContent = essai.id ?? '';
                    modalNom.textContent = essai.nom ?? '';
                    modalPrenom.textContent = essai.prenom ?? '';
                    modalEmail.textContent = essai.email ?? '';
                    modalLieurecup.textContent = essai.lieurecup ?? '';
                    modalLieudepot.textContent = essai.lieudepot ?? '';
                    modalDaterecup.textContent = essai.daterecup ?? '';
                    modalDatedepot.textContent = essai.datedepot ?? '';
                    modalHeurerrecup.textContent = essai.heurerrecup ?? '';
                    editId.value = essai.id ?? '';
                    editLieurecup.value = essai.lieurecup ?? '';
                    editLieudepot.value = essai.lieudepot ?? '';
                    editDaterecup.value = essai.daterecup ?? '';
                    editDatedepot.value = essai.datedepot ?? '';
                    editHeurerrecup.value = essai.heurerrecup ?? '';
                    btnDelete.setAttribute('onclick', `if(confirm('Confirmer la suppression de la demande #${essai.id}?')) window.location.href='?delete=${encodeURIComponent(essai.id)}'`);
                    essaiModal.show();
                });
            });

            // Gestion des alertes temporaires
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                setTimeout(() => alert.classList.remove('show'), 3000);
            });
        });
    </script>
</body>
</html>