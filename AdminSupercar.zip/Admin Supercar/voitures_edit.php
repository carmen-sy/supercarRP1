<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (!isset($_GET['id'])) {
        die("ID manquant !");
    }

    $id = (int) $_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM voiture WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $voiture = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$voiture) {
        die("Voiture introuvable !");
    }
} catch(PDOException $e) {
    echo "Erreur : " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modification</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container py-5">
  <h2 class="text-center mb-4">Modifier la voiture #<?= htmlspecialchars($voiture['id']) ?></h2>

  <form action="voitures_update.php" method="post" class="bg-white p-4 rounded shadow-sm">
    <input type="hidden" name="id" value="<?= htmlspecialchars($voiture['id']) ?>">

    <div class="row">
      <!-- Colonne gauche -->
      <div class="col-md-6">
        <div class="mb-3">
          <label class="form-label">Marque</label>
          <input type="text" name="marque" class="form-control" 
                 value="<?= htmlspecialchars($voiture['marque']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Modèle</label>
          <input type="text" name="modele" class="form-control" 
                 value="<?= htmlspecialchars($voiture['modele']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Prix (en MUR / XXXX.00)</label>
          <input type="number" step="0.01" name="prix" class="form-control" 
                 value="<?= htmlspecialchars($voiture['prix']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Photo (Chemin d'accès)</label>
          <input type="text" name="photo" class="form-control" 
                 value="<?= htmlspecialchars($voiture['photo']) ?>">
        </div>
      </div>

      <!-- Colonne droite -->
      <div class="col-md-6">
        <div class="mb-3">
          <label class="form-label">Catégorie</label>
          <input type="text" name="categorie" class="form-control" 
                 value="<?= htmlspecialchars($voiture['categorie']) ?>">
        </div>

        <div class="mb-3">
          <label class="form-label">Description</label>
          <textarea name="description" class="form-control" rows="3"><?= htmlspecialchars($voiture['description']) ?></textarea>
        </div>

        <div class="mb-3">
          <label class="form-label">Transmission</label>
          <input type="text" name="transmission" class="form-control" 
                 value="<?= htmlspecialchars($voiture['transmission']) ?>">
        </div>

        <div class="form-check mb-3">
          <input type="checkbox" name="disponible" value="1" 
                 class="form-check-input" id="disponibleCheck"
                 <?= $voiture['disponible'] ? 'checked' : '' ?>>
          <label class="form-check-label" for="disponibleCheck">Disponible</label>
        </div>
      </div>
    </div>

    <!-- Boutons -->
    <div class="d-flex justify-content-between">
      <a href="voitures.php" class="btn btn-secondary">Annuler</a>
      <button type="submit" class="btn btn-primary">Enregistrer</button>
    </div>
  </form>
</div>


</body>
</html>
