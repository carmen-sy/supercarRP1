<?php
session_start();
if (!isset($_SESSION['admin'])) {
  header("Location: Index.php");
  exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "supercar";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); $stmt =
  $conn->query("SELECT * FROM voiture"); $voitures =
  $stmt->fetchAll(PDO::FETCH_ASSOC); } catch(PDOException $e) { echo "Erreur : " .
  $e->getMessage(); } $conn = null;
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8" />
    <title>Voitures - Admin</title>

    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <style>
      body {
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f6f9;
        margin: 0;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
      }
      .navbar {
        background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
        padding: 0.85rem 1.5rem;
        position: fixed;
        top: 0;
        width: 100%;
        z-index: 999;
        display: flex;
        justify-content: space-between;
        align-items: center;
      }
      main.content {
        padding-top: 100px;
        padding-bottom: 80px;
        flex: 1;
      }
      footer {
        background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
        color: white;
        text-align: center;
        padding: 0.9rem;
        position: fixed;
        bottom: 0;
        width: 100%;
        box-shadow: 0 -5px 15px rgba(0, 0, 0, 0.1);
      }
      .user-info {
        text-align: right;
        color: #fff;
      }
      .table-hover tbody tr:hover {
            cursor: pointer;
            background-color: #f8f9fa;
        }
        .modal-content {
            border-radius: 10px;
        }
        .list-group-item {
            border: none;
        }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg">
      <div class="navbar-brand text-white fw-bold">SuperCar - Admin</div>
      <div class="nav-menu d-flex justify-content-center flex-grow-1">
        <ul class="navbar-nav d-flex flex-row">
          <li class="nav-item px-2">
            <a href="Index.php" class="nav-link text-white acitve"
              >Dashboard</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="Gestion_utilisateur.php" class="nav-link text-white"
              >Utilisateurs</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="voitures.php" class="nav-link text-white">Voitures</a>
          </li>
          <li class="nav-item px-2">
            <a href="Demande.php" class="nav-link text-white"
              >Demande d'essai</a
            >
          </li>
          <li class="nav-item px-2">
            <a href="messages.php" class="nav-link text-white"
              >Messages & Contacts</a
            >
          </li>
        </ul>
      </div>
      <div class="user-info">
        <div class="fw-bold">
          <?php
                $email = $_SESSION['admin'] ?? 'admin@example.com';
                $username = explode('@', $email)[0];
                echo htmlspecialchars($username);
                ?>
        </div>
        <a href="logout.php" class="text-white" style="font-size: 0.85rem"
          ><i class="fas fa-sign-out-alt"></i> Déconnexion</a
        >
      </div>
    </nav>

<main class="content container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h4 mb-0">Liste des voitures</h1>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addCarModal">
          + Ajouter une voiture
        </button>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-0">
                <table class="table table-bordered table-hover mb-0" id="carTable">
                    <thead class="table-dark">
                        <tr>
                            <th style="width: 80px">ID</th>
                            <th>Marque</th>
                            <th>Modèle</th>
                            <th>Prix (en MUR)</th>
                            <th>Photo (Chemin d'accès)</th>
                            <th>Catégorie</th>
                            <th>Description</th>
                            <th>Transmission</th>
                            <th>Disponible</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($voitures as $v): ?>
                        <tr data-id="<?= $v['id'] ?>" class="clickable-row">
                            <td><?= htmlspecialchars($v['id']) ?></td>
                            <td><?= htmlspecialchars($v['marque']) ?></td>
                            <td><?= htmlspecialchars($v['modele']) ?></td>
                            <td><?= number_format($v['prix'], 2) ?></td>
                            <td><?= htmlspecialchars($v['photo'] ?? 'Non spécifiée') ?></td>
                            <td><?= htmlspecialchars($v['categorie'] ?? 'Non spécifiée') ?></td>
                            <td><?= htmlspecialchars($v['description'] ?? 'Aucune description') ?></td>
                            <td><?= htmlspecialchars($v['transmission'] ?? 'Non spécifiée') ?></td>
                            <td><?= $v['disponible'] ? 'Oui' : 'Non' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal fade" id="carModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                      <h5 class="modal-title">Détails de la voiture</h5>
                      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row g-3">
                            <div class="col-6">
                                <ul class="list-group">
                                    <li class="list-group-item"><strong>Marque :</strong> <span id="marque"></span></li>
                                    <li class="list-group-item"><strong>Modèle :</strong> <span id="modele"></span></li>
                                    <li class="list-group-item"><strong>Prix (en MUR) :</strong> <span id="prix"></span></li>
                                    <li class="list-group-item"><strong>Photo (Chemin d'accès) :</strong> <span id="photo"></span></li>
                                </ul>
                            </div>
                            <div class="col-6">
                                <ul class="list-group">
                                    <li class="list-group-item"><strong>Catégorie :</strong> <span id="categorie"></span></li>
                                    <li class="list-group-item"><strong>Description :</strong> <span id="description"></span></li>
                                    <li class="list-group-item"><strong>Transmission :</strong> <span id="transmission"></span></li>
                                    <li class="list-group-item"><strong>Disponible :</strong> <span id="disponible"></span></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                      <a href="voitures_edit.php?id=<?= $v['id'] ?>" id="btnEdit" class="btn btn-warning">Modifier</a>
                      <a href="voitures_delete.php?id=<?= $v['id'] ?>" id="btnDelete" class="btn btn-danger" onclick="return confirm('Voulez-vous vraiment supprimer cette voiture ?')">Supprimer</a>
                    </div>
                </div>
            </div>
        </div>

    <div class="modal fade" id="addCarModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <form action="voitures_add.php" method="POST">
            <div class="modal-header">
              <h5 class="modal-title">Ajouter une nouvelle voiture</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <div class="modal-body row g-3">
              <div class="col-md-6">
                <label class="form-label">Marque</label>
                <input type="text" name="marque" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Modèle</label>
                <input type="text" name="modele" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Prix (MUR / XXXX.00)</label>
                <input type="number" step="0.01" name="prix" class="form-control" required>
              </div>
              <div class="col-md-6">
                <label class="form-label">Photo (chemin ou URL)</label>
                <input type="text" name="photo" class="form-control">
              </div>
              <div class="col-md-6">
                <label class="form-label">Catégorie</label>
                <input type="text" name="categorie" class="form-control">
              </div>
              <div class="col-md-6">
                <label class="form-label">Transmission</label>
                <input type="text" name="transmission" class="form-control">
              </div>
              <div class="col-12">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control"></textarea>
              </div>
              <div class="col-12 form-check">
                <input type="checkbox" name="disponible" value="1" class="form-check-input" id="dispoCheck">
                <label class="form-check-label" for="dispoCheck">Disponible</label>
              </div>
            </div>
            <div class="modal-footer">
              <button type="submit" class="btn btn-success">Ajouter</button>
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annuler</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    </main>

    <footer>
        © SUPERCAR 2024-2026 | Admin MCCI | SIO
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
        document.addEventListener('DOMContentLoaded', function() {
            // Sélectionner toutes les lignes cliquables
            const rows = document.querySelectorAll('#carTable .clickable-row');
            const modal = new bootstrap.Modal(document.getElementById('carModal'));

            rows.forEach(row => {
                row.addEventListener('click', function() {
                    // Récupérer les données de la ligne
                    const cells = this.getElementsByTagName('td');
                    const id = this.getAttribute('data-id');
                    const marque = cells[1].textContent;
                    const modele = cells[2].textContent;
                    const prix = cells[3].textContent;
                    const photo = cells[4].textContent;
                    const categorie = cells[5].textContent;
                    const description = cells[6].textContent;
                    const transmission = cells[7].textContent;
                    const disponible = cells[8].textContent;

                    // Remplir la modale avec les données
                    document.getElementById('modele').textContent = modele;
                    document.getElementById('marque').textContent = marque;
                    document.getElementById('prix').textContent = prix;
                    document.getElementById('photo').textContent = photo;
                    document.getElementById('categorie').textContent = categorie;
                    document.getElementById('description').textContent = description;
                    document.getElementById('transmission').textContent = transmission;
                    document.getElementById('disponible').textContent = disponible;

                    // Ajouter l'ID à l'élément de modification (si nécessaire pour une future action)
                    document.getElementById('btnEdit').setAttribute('href', 'voitures_edit.php?id=' + id);
                    document.getElementById('btnDelete').setAttribute('href', 'voitures_delete.php?id=' + id);

                    // Afficher la modale
                    modal.show();
                });
            });
        });
    </script>
  </body>
</html>
