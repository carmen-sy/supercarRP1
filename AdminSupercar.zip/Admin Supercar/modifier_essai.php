<?php
$conn = new mysqli("localhost", "root", "", "supercar");
if ($conn->connect_error) die("Erreur : " . $conn->connect_error);

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $stmt = $conn->prepare("UPDATE essai SET nom=?, prenom=?, email=?, lieurecup=?, lieudepot=?, daterecup=?, datedepot=?, heurerrecup=? WHERE id=?");
    $stmt->bind_param(
        "ssssssssi",
        $_POST['nom'],
        $_POST['prenom'],
        $_POST['email'],
        $_POST['lieurecup'],
        $_POST['lieudepot'],
        $_POST['daterecup'],
        $_POST['datedepot'],
        $_POST['heurerrecup'],
        $_POST['id']
    );
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header("Location: essais.php"); // <-- modifie si besoin
    exit;
}

// Récupération des données à modifier
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = $conn->query("SELECT * FROM essai WHERE id = $id");
    $data = $result->fetch_assoc();
} else {
    echo "ID non spécifié.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Modifier un essai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h1 class="mb-4">Modifier un essai</h1>
    <form method="POST">
        <input type="hidden" name="id" value="<?= htmlspecialchars($data['id']) ?>">

        <div class="mb-3">
            <label>Nom</label>
            <input type="text" name="nom" class="form-control" value="<?= htmlspecialchars($data['nom']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Prénom</label>
            <input type="text" name="prenom" class="form-control" value="<?= htmlspecialchars($data['prenom']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($data['email']) ?>" required>
        </div>
        <div class="mb-3">
            <label>Lieu de récupération</label>
            <input type="text" name="lieurecup" class="form-control" value="<?= htmlspecialchars($data['lieurecup']) ?>">
        </div>
        <div class="mb-3">
            <label>Lieu de dépôt</label>
            <input type="text" name="lieudepot" class="form-control" value="<?= htmlspecialchars($data['lieudepot']) ?>">
        </div>
        <div class="mb-3">
            <label>Date de récupération</label>
            <input type="date" name="daterecup" class="form-control" value="<?= htmlspecialchars($data['daterecup']) ?>">
        </div>
        <div class="mb-3">
            <label>Date de dépôt</label>
            <input type="date" name="datedepot" class="form-control" value="<?= htmlspecialchars($data['datedepot']) ?>">
        </div>
        <div class="mb-3">
            <label>Heure de récupération</label>
            <input type="time" name="heurerrecup" class="form-control" value="<?= htmlspecialchars($data['heurerrecup']) ?>">
        </div>

        <button type="submit" class="btn btn-primary">Enregistrer les modifications</button>
        <a href="essais.php" class="btn btn-secondary">Annuler</a>
    </form>
</body>
</html>
