<?php
// supprimer_essai.php

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    $conn = new mysqli("localhost", "root", "", "supercar");
    if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);

    $stmt = $conn->prepare("DELETE FROM essai WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $stmt->close();
    $conn->close();

    // Redirection avec message
    header("Location: Gestion_utilisateur.php?deleted=1");
    exit;
} else {
    echo "L'utilisateur a bien ete Supprimer.";
}
?>
