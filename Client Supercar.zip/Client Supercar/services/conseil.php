<?php
session_start();

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Destroy session
    session_unset();
    session_destroy();
    // Clear cookies
    setcookie('user_id', '', time() - 3600, '/');
    setcookie('user_nom', '', time() - 3600, '/');
    // Redirect to Acceuil.php
    header("Location: Acceuil.php");
    exit();
}

// Récupérer la session depuis les cookies si elle n'existe pas
if (!isset($_SESSION["user_id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["user_id"] = $_COOKIE["user_id"];
    $_SESSION["user_nom"] = $_COOKIE["user_nom"];
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>SuperCar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <link rel="stylesheet" href="../css/aos.css">

    <link rel="stylesheet" href="../css/ionicons.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container-fluid px-0">


      
          <!-- Logo à gauche -->
          <a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">
              Super<span>car</span>
          </a>
          
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
              <span class="oi oi-menu"></span> Menu
          </button>
  
          <div class="collapse navbar-collapse" id="ftco-nav">


              <!-- Menu centré -->
              <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
                  <li class="nav-item "><a href="../Acceuil.php" class="nav-link">Accueil</a></li>:
                  <li class="nav-item"><a href="../car.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item active"><a href="../services.php" class="nav-link">Services</a></li>


                  
                  <!-- Groupe Demande d'essai + Contact -->
                  <li class="nav-item" style="display: inline-flex;">
                      <a href="../demande.php" class="nav-link" style="white-space: nowrap;">Demande d'essai</a>
                      <span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
                      <a href="../contacts.php" class="nav-link" style="white-space: nowrap;">Contactez-nous</a>
                  </li>
              </ul>

              

           <!-- User or Login -->
           <div class="navbar-text user-info">
                  <?php if (isset($_SESSION['user_id'])): ?>
                      <i class="fas fa-user" style="font-size: 0.9rem;"></i>
                      <?php
                      // Display the user's name from session
                      $username = $_SESSION['user_nom'] ?? 'Utilisateur';
                      echo htmlspecialchars($username);
                      ?>
                      <a href="?action=logout" class="nav-link logout-btn">
                          <i class="fas fa-sign-out-alt"></i> Déconnexion
                      </a>
                  <?php else: ?>
                      <a href="connexion.php" class="nav-link">Se connecter</a>
                  <?php endif; ?>
              
            
          </div>
      </div>
  </nav>
  
    
    <style>
      /* Ajustements pour le groupe de liens */
      @media (min-width: 992px) {
        .navbar-nav .nav-item[style*="inline-flex"] {
          display: inline-flex !important;
          align-items: center;
        }
        
        .navbar-brand {
          position: relative;
          left: -30px;
        }
        
        #ftco-nav {
          width: calc(100% - 100px);
        }
      }
      
      /* Version mobile */
      @media (max-width: 991px) {
        .navbar-nav .nav-item[style*="inline-flex"] {
          display: block !important;
        }
        
        .navbar-nav .nav-item[style*="inline-flex"] span {
          display: none;
        }
      }
    </style>
    
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('../images/imm.png');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs">
              <span class="mr-2">
                <a href="../Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a>
              </span>
              <span class="mr-2">
                <a href="../services.php">Services</a> <i class="ion-ios-arrow-forward"></i>
              </span>
              <span>
                <a href="../services/conseil.php">Conseils et pratiques</a>
              </span>
            </p>
          
            <h1 class="mb-3 bread">Nos Conseils pratiques</h1>
          </div>
        </div>
      </div>
      <section id="services" class="services section">
		<div data-aos="fade-up">
		</div><!-- End Section Title -->
	
		  <div class="container">
	
			  <div data-aos="fade-up" data-aos-delay="100">
				<div class="service-item">
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            margin: 20px;
                            padding: 20px;
                            background-color: #f4f4f4;
                        }
                        .contain {
                            max-width: 800px;
                            margin: auto;
                            background: white;
                            padding: 20px;
                            border-radius: 10px;
                            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        }
                        h1 {
                            text-align: center;
                        }
                        h2 {
                            color: #333;
                            border-bottom: 2px solid #ddd;
                            padding-bottom: 5px;
                        }
                        p {
                            line-height: 1.6;
                            color: #555;
                        }
                        i{
                            color: #b3d616;
                        }

                    </style>
</head>
<body>
 <h1>
    6 Gestes primordiaux
 </h1>
</p>
<p>
<ul>
  <li><i class="bi bi-check2-all"></i> <span>Vérifier régulièrement les niveaux</span></li>
  <li><i class="bi bi-check2-all"></i> <span>Vérifier l’état des pneus</span></li>
  <li><i class="bi bi-check2-all"></i> <span>Surveiller les freins</span></li>
  <li><i class="bi bi-check2-all"></i> <span>Protéger la voiture des intmpéries</span></li>
  <li><i class="bi bi-check2-all"></i> <span>Contrôler les éclairages</span></li>
  <li><i class="bi bi-check2-all"></i> <span>Laver régulièrement le véhicule</span></li>
</ul>
</p>

<div class="contain">
    <h1>1.Vérification des niveaux de liquides</h1>
    <p>La vérification régulière des niveaux de liquides est un excellent réflexe à avoir. Ce geste prévient les risques de panne, les problèmes mécaniques et d’éventuels accidents.</p>
    
    <h2>Liquide de transmission</h2>
    <p>La vérification du liquide de transmission se fait généralement lorsque le moteur est allumé et encore chaud. En vous référant au manuel du propriétaire de votre véhicule, trouvez la jauge du liquide de transmission. Retirez complètement la jauge et essuyez-la avec un vieux chiffon, puis replongez de nouveau la jauge dans le carter. Sortez-la de nouveau et lisez le niveau de liquide indiqué. 
        Vérifiez que le niveau de liquide correspond à celui indiqué dans le manuel et ajustez-le si nécessaire.</p>
    
    <h2>L’huile moteur</h2>
    <p>Attention, il convient de vérifier le niveau d’huile moteur 1 heure après avoir éteint le moteur. Autrement, vous risquez de vous faire asperger d’huile brûlante ou de mal lire le niveau. L’opération à effectuer est exactement la même que pour le liquide de transmission. De nouveau, 
        il faut vérifier que le niveau est bien situé entre les deux marques sur la jauge.</p>
    
    <h2>Liquide de frein</h2>
    <p>Il s’agit du liquide utilisé pour nettoyer le pare-brise. Peu coûteux, il permet de retirer les insectes et saletés qui restent collés sur le pare-brise de la voiture. En hiver,
         optez pour un liquide lave-glace antigel, pour éviter les mauvaises surprises.</p>
    <p>Une fois que vous aurez pris l’habitude de vérifier régulièrement vos niveaux, cette opération ne vous prendra que quelques minutes.</p>


    <h1> 2. Vérifier l’état des pneus pour entretenir son véhicule</h1>
    <p>Les pneus sont les seuls points de contact entre l’automobile et la route. Rouler avec des pneus usés est synonyme de danger. En effet, plus le pneu est lisse, plus les risques de dérapage, perte de contrôle du véhicule et crevaison sont élevés.
         Il convient donc de bien entretenir ses pneus.</p>
    <h2>L’état des reliefs</h2>
    <p>Les reliefs du pneu doivent être profonds, visibles et bien sculptés. Le code de la route précise qu’ils ne doivent pas faire moins de 1,6 mm. 
        Vous pouvez facilement vérifier leur profondeur grâce aux témoins d’usure présents dans les rainures principales du pneu.</p>
    
    <h2>La pression des pneus</h2>
    <p>Il est conseillé de vérifier la pression des pneus au moins une fois par mois.
         Pour cela, rendez-vous dans une station service ou procurez-vous un nanomètre.</p>
    
    <h2>Les flancs</h2>
    <p>Contrôlez la partie latérale du pneu. Regardez qu’il n’y ait aucune boursouflure ni de déchirure. Sinon, il est temps de changer de pneu !.</p>
    <p>si vous rencontrez un problème avec vos pneus contactez un concessionnaire</p>

    <h1> 3. Faire surveillez les freins</h1>
    <p>Pour faire l’entretien régulier de votre voiture, surveillez les freins. Le garagiste doit vérifier les plaquettes de freins et les disques au moins une fois par an. 
        Il devra également voir si le freinage ne présente pas des bruits anormaux ou des grincements inhabituels.</p>

        <h1>4. Protéger la voiture des intempéries</h1>
        <p>Votre voiture vit au rythme des quatre saisons. Pluie, neige, chaleur, soleil abîment prématurément la carrosserie de votre véhicule. Pour protéger au mieux votre voiture, investissez dans une bâche de protection intégrale et des pare-soleil. Autre conseil pour une voiture impeccable :
             garez-vous à l’ombre et évitez de vous stationner sous les arbres.</p>

        <h1> 5. Contrôler les éclairages</h1>
        <p>Prendre la route de nuit avec de mauvais éclairages ou une ampoule grillée est très dangereux. Pour bien voir et être vu, vérifiez régulièrement tous vos feux : position, croisement, route, recul, stop, antibrouillard, sans oublier les clignotants. 
            Astuce : faites-vous aider d’une tierce personne pour effectuer cette opération.</p>

        <h1>6. Laver régulièrement son véhicule</h1>
        <p>Le nettoyage intérieur et le nettoyage extérieur rallongent la durée de vie de votre véhicule. En fonction de la météo et de l’usage que vous faites de votre voiture, 
            il est conseillé de laver entre 1 et 4 fois par mois l’intérieur et l’extérieur.</p>
        <p> Lavage aux rouleaux, haute pression, tunnel de lavage… 
            Choisissez le mode de lavage extérieur le plus adapté à vos besoins dans un centre de lavage proche de chez vous. Concernant l’intérieur du véhicule, pensez à nettoyer les sièges, le sol, les tapis et le tableau de bord.</p>
</body>

<footer 

style="
background: linear-gradient(135deg, #247eec, #12906c, #2d73ed);
color: white;
padding: 1.5rem 0;
text-align: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
position: relative;
margin-top: 3rem;
box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
">
<div style="
	max-width: 1200px;
	margin: 0 auto;
	padding: 0 20px;
">
	<p style="
		margin: 0;
		font-size: 1.1rem;
		letter-spacing: 1px;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 10px;
		flex-wrap: wrap;
	">
		<span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>By Student MCCI</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>SIO</span>
	</p>
	
	<div style="
		margin-top: 1rem;
		display: flex;
		justify-content: center;
		gap: 1.5rem;
	">
		<a href="../contacts.php" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-envelope"></i> Contact
		</a>
		<a href="../confidentialité.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-shield-alt"></i> Confidentialité
		</a>
		<a href="../Mention.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-file-alt"></i> Mentions légales
	</div>
</div>
</footer>
</html>

<script src="../js/jquery.min.js"></script>
<script src="../js/jquery-migrate-3.0.1.min.js"></script>
<script src="../js/popper.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/jquery.waypoints.min.js"></script>
<script src="../js/jquery.stellar.min.js"></script>
<script src="../js/owl.carousel.min.js"></script>
<script src="../js/jquery.magnific-popup.min.js"></script>
<script src="../js/aos.js"></script>
<script src="../js/jquery.animateNumber.min.js"></script>
<script src="../js/bootstrap-datepicker.js"></script>
<script src="../js/jquery.timepicker.min.js"></script>
<script src="../js/scrollax.min.js"></script>
<script src="../js/main.js"></script>
  