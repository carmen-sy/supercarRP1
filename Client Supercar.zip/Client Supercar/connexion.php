<?php
session_start();
$host = "localhost";
$login = "root";
$pass = "";
$bdd = "supercar";

// Connexion à la base de données
$conn = new mysqli($host, $login, $pass, $bdd);
if ($conn->connect_error) {
    die("Erreur de connexion : " . $conn->connect_error);
}

$error = ""; // Initialisation de la variable pour afficher les erreurs

// Vérifier si l'utilisateur a déjà un cookie et restaurer la session
if (!isset($_SESSION["user_id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["user_id"] = $_COOKIE["user_id"]; // Restauration de la session
    header("Location: dashboard.php");
    exit();
}

// Vérifier si le formulaire est soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"] ?? "";
    $password = $_POST["password"] ?? "";

    // Requête pour récupérer l'utilisateur
    $sql = "SELECT id, nom, password FROM inscription WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Vérification des identifiants
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user["password"])) {
            $_SESSION["user_id"] = $user["id"];
            $_SESSION["user_nom"] = $user["nom"];

            // Vérifier si "Se souvenir de moi" est coché
            if (isset($_POST["remember_me"])) {
                setcookie("user_id", $user["id"], time() + (86400 * 30), "/"); // Cookie valide 30 jours
            }

            header("Location: dashboard.php"); // Redirection après connexion
            exit();
        } else {
            $error = "Mot de passe incorrect.";
        }
    } else {
        $error = "Email non trouvé.";
    }

    $stmt->close();

    if (password_verify($password, $user["password"])) {
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_nom"] = $user["nom"];
    
        // Création d'un cookie pour une connexion persistante (durée 7 jours)
        setcookie("user_id", $user["id"], time() + (7 * 24 * 60 * 60), "/");
        setcookie("user_nom", $user["nom"], time() + (7 * 24 * 60 * 60), "/");
    
        header("Location: dashboard.php");
        exit();
    }
    
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">



<head>
<meta charset="utf-8">
<title>Connexion</title>
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/all.min.css">
 
	<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">



   
   

    <style>
    body, html {
        height: 100%;
        margin: 0;
    }

    .video-bg {
        position: fixed;
        top: 0;
        left: 0;
        min-width: 100%;
        min-height: 100%;
        z-index: -1;
        object-fit: cover;
    }

    .center-container {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

</head>



<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container-fluid px-0">
          <!-- Logo à gauche -->
          <a class="navbar-brand ml-lg-5 ml-3" href="Acceuil.php" style="margin-right: -50px;">
              Super<span>car</span>
          </a>
          
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
              <span class="oi oi-menu"></span> Menu
          </button>
  
          <div class="collapse navbar-collapse" id="ftco-nav">
              <!-- Menu centré -->
              <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
                  <li class="nav-item"><a href="Acceuil.php" class="nav-link">Accueil</a></li>
                  <li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
                  
                  <!-- Groupe Demande d'essai + Contact -->
                  <li class="nav-item" style="display: inline-flex;">
                      <a href="Demande.php" class="nav-link active" style="white-space: nowrap;">Demande d'essai</a>
                      <span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
                      <a href="contacts.php" class="nav-link" style="white-space: nowrap;">Contactez-nous</a>
                  </li>
              </ul>
              
              <!-- Inscription à droite -->
              <ul class="navbar-nav" style="margin-right: 50px;">
                <li class="nav-item">
                    <a href="inscription.html" class="nav-link">
                        <i class="fas fa-user-plus"></i> s'inscrire
                    </a>
                </li>
            </ul>
            
          </div>
      </div>
  </nav>
  
  <style>
      /* Ajustements pour le groupe de liens */
      @media (min-width: 992px) {
          .navbar-nav .nav-item[style*="inline-flex"] {
              display: inline-flex !important;
              align-items: center;
          }
          
          .navbar-brand {
              position: relative;
              left: -30px;
          }
          
          #ftco-nav {
              width: calc(100% - 100px);
          }
      }
      
      /* Version mobile */
      @media (max-width: 991px) {
          .navbar-nav .nav-item[style*="inline-flex"] {
              display: block !important;
          }
          
          .navbar-nav .nav-item[style*="inline-flex"] span {
              display: none;
          }
      }
  </style>

<!-- Vidéo en fond -->
<video autoplay muted loop class="video-bg">
    <source src="video/Car Turning On Hazard .mp4" type="video/mp4">
</video>
<div style="
    position: fixed;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background: rgba(0, 0, 0, 0.4);
    z-index: 0;
"></div>

<div class="center-container">
    <div class="col-lg-4 bg-white p-4 rounded-top shadow">
                <h2 class="text-center">Connexion</h2>
                <p class="text-center text-muted lead">Se connecter à SuperCar</p>
                  
                <form action="connexion.php" method="POST">
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fa fa-envelope"></i></span>
                        <input type="text" name="email" class="form-control" placeholder="Votre E-mail" required>
                    </div>
                
                    <div class="input-group mb-3">
                        <span class="input-group-text"><i class="fa fa-lock"></i></span>
                        <input type="password" name="password" id="password" class="form-control" placeholder="Votre Mot de passe" required>
                        <span class="input-group-text" id="togglePassword" style="cursor: pointer;">
                            <i class="fa fa-eye" aria-hidden="true"></i>
                        </span>
                    </div>

                    <!-- Case à cocher "Se souvenir de moi" -->
                    <div class="form-check mb-3">
                        <input class="form-check-input" type="checkbox" name="remember_me" id="rememberMe">
                        <label class="form-check-label" for="rememberMe">
                            Se souvenir de moi
                        </label>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-success w-100 py-2">Se connecter</button>
                        <?php if (!empty($error)) : ?>
                        <p class="text-danger text-center"><?= $error ?></p>
                        <?php endif; ?>
                        <p class="text-center">
                            N'avez-vous pas de compte ? <a href="inscription.html">S'inscrire</a>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <footer style="
background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
color: white;
padding: 1.5rem 0;
text-align: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
position: relative;
margin-top: 3rem;
box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
">
<div style="
	max-width: 1200px;
	margin: 0 auto;
	padding: 0 20px;
">
	<p style="
		margin: 0;
		font-size: 1.1rem;
		letter-spacing: 1px;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 10px;
		flex-wrap: wrap;
	">
		<span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>By Student MCCI</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>SIO</span>
	</p>
	
	<div style="
		margin-top: 1rem;
		display: flex;
		justify-content: center;
		gap: 1.5rem;
	">
    
		<a href="contact.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-envelope"></i> Contact
		</a>
		<a href="confidentialité.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-shield-alt"></i> Confidentialité
		</a>
		<a href="#" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-file-alt"></i> Mentions légales
		</a>
	</div>
</div>
</footer>
</body>
</html>
<script src="bootstrap.bundle.js"></script>
<script>
document.getElementById('togglePassword').addEventListener('click', function () {
    const password = document.getElementById('password');
    const eye = this.querySelector('i');
    if (password.type === 'password') {
        password.type = 'text';
        eye.classList.remove('fa-eye');
        eye.classList.add('fa-eye-slash');
    } else {
        password.type = 'password';
        eye.classList.remove('fa-eye-slash');
        eye.classList.add('fa-eye');
    }
});
</script>