<?php
session_start();

// Vérifier si un message a déjà été envoyé
if (isset($_SESSION['message_envoye'])) {
    echo "Vous avez déjà envoyé un message.";
    exit;
}

$host = "localhost";
$login = "root";
$pass = "";
$bdd = "supercar";

$conn = new mysqli($host, $login, $pass, $bdd);

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

//Verification et recuperation du formulaire
    $nom = htmlspecialchars($_POST["nom"]);
    $email=htmlspecialchars($_POST["email"]);
    $sujet =htmlspecialchars($_POST["sujet"]);
    $message =htmlspecialchars($_POST["message"]);

    if (!$nom || !$email) {
        die("Erreur : tous les champs requis ne sont pas remplis !");
    }

    // Insérer dans la base de données
    $contacte = "INSERT INTO contactez (nom,email,sujet,message) 
                 VALUES ('$nom','$email','$sujet','$message')";

if ($conn->query($contacte) === TRUE) {
    $_SESSION['message_envoye'] = true;
    echo "Message envoyé avec succès !";
} else {
    echo "Erreur : " . $conn->error;
}


