-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : jeu. 03 avr. 2025 à 05:20
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `supercar`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Structure de la table `contactez`
--

DROP TABLE IF EXISTS `contactez`;
CREATE TABLE IF NOT EXISTS `contactez` (
  `idclient` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `sujet` varchar(40) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idclient`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `contactez`
--

INSERT INTO `contactez` (`idclient`, `nom`, `email`, `sujet`, `message`) VALUES
(1, 'Bilounga ingrid', 'nkpweeingrid@gmail.com', 'nnnn', 'dyugguhkjo'),
(2, 'Bilounga ingrid', 'nkpweeingrid@gmail.com', 'nnnn', 'dyugguhkjo'),
(3, 'Jodelus', 'jodelus@gmail.com', 'jjjjjjjjjj', 'Bo,jiujnd'),
(4, 'ingrid ', 'h@gmail.com', 'journe', 'allo'),
(5, 'ingri', 'ing@gmail.com', 'bonjour', 'cava?');

-- --------------------------------------------------------

--
-- Structure de la table `essai`
--

DROP TABLE IF EXISTS `essai`;
CREATE TABLE IF NOT EXISTS `essai` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `lieurecup` varchar(255) DEFAULT NULL,
  `lieudepot` varchar(255) DEFAULT NULL,
  `daterecup` date DEFAULT NULL,
  `datedepot` date DEFAULT NULL,
  `heurerecup` time DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `essai`
--

INSERT INTO `essai` (`id`, `ref_voiture`, `nom`, `prenom`, `email`, `lieurecup`, `lieudepot`, `daterecup`, `datedepot`, `heurerecup`) VALUES
(1, '123', 'alphabet', 'francais', 'alpha@gmail.com', 'quatres bornes', 'saint jean', '0000-00-00', '0000-00-00', '00:00:00'),
(2, '356', 'luca', 'ing', 'kl@gmail.com', 'quatres bornes', 'saint jean', '0000-00-00', '0000-00-00', '12:30:00'),
(3, '356', 'luca', 'ing', 'kl@gmail.com', 'quatres bornes', 'saint jean', '0000-00-00', '0000-00-00', '00:00:00'),
(4, 'toy2', 'ingrid', 'ingrid', 'ingrid@gmail.com', 'yaounde', 'douala', '0000-00-00', '0000-00-00', '11:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `inscription`
--

DROP TABLE IF EXISTS `inscription`;
CREATE TABLE IF NOT EXISTS `inscription` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_inscription` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `inscription`
--

INSERT INTO `inscription` (`id`, `nom`, `prenom`, `email`, `ville`, `password`, `date_inscription`) VALUES
(1, 'ffff', 'jj', 'ingrid26', 'Quatre Bornes', '$2y$10$EyU0j2vHfQ3vAl6OcmbFC.VUDE8YXpGME3D56BkLnbotDYavgekt.', '2025-03-27 06:49:38'),
(3, 'Ludeville', 'jean', 'jean@gmail.com', 'Yaounde', '$2y$10$Cu1mE29J3LiyDOvttcVo7OsrpnkdA103O9LtLDU37BBBKAsAdHxUC', '2025-03-27 07:03:50'),
(4, 'Fokou', 'Gabriel', 'Gabriel@gmail.com', 'st pierre', '$2y$10$SefhRnwTbGqZKuOq1lahHuX/IqbG2tQJQNmmxUuUlj.zxeMjeQdTS', '2025-03-28 02:08:46'),
(5, 'julie', 'julie', 'julie@gmail.com', 'avenue surath', '$2y$10$cR34DDsrBhonwbLcNKXhweWzjGyzX05HMShQPGLQNOAju.QYJsZNy', '2025-03-31 10:52:27'),
(6, 'junior', 'junior', 'junior@gmail.com', 'douala', '$2y$10$UO2NAHGTjFVqwQ22KBffKutfWigmiJrj6QHFAx6jRbP6JLDFwpEeq', '2025-04-03 03:11:18'),
(7, 'carmen', 'carmen', 'carmen@gmail.com', 'st jean', '$2y$10$t96PPNR9MUtclM60qy5NxehdwlhYc.wRvP3kPj1rIiJWEgrDEWQ52', '2025-04-03 04:58:48');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
