<?php
session_start();

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Destroy session
    session_unset();
    session_destroy();
    // Clear cookies
    setcookie('user_id', '', time() - 3600, '/');
    setcookie('user_nom', '', time() - 3600, '/');
    // Redirect to Acceuil.php
    header("Location: Acceuil.php");
    exit();
}

// Récupérer la session depuis les cookies si elle n'existe pas
if (!isset($_SESSION["user_id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["user_id"] = $_COOKIE["user_id"];
    $_SESSION["user_nom"] = $_COOKIE["user_nom"];
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Supercar-WEB</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
	  
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container-fluid px-0">


      
          <!-- Logo à gauche -->
          <a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">
              Super<span>car</span>
          </a>
          
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
              <span class="oi oi-menu"></span> Menu
          </button>
  
          <div class="collapse navbar-collapse" id="ftco-nav">


              <!-- Menu centré -->
              <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
                  <li class="nav-item "><a href="Acceuil.php" class="nav-link">Accueil</a></li>
                  <li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>


                  
                  <!-- Groupe Demande d'essai + Contact -->
                  <li class="nav-item" style="display: inline-flex;">
                      <a href="demande.php" class="nav-link" style="white-space: nowrap;">Demande d'essai</a>
                      <span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
                      <a href="contacts.php" class="nav-item active" style="white-space: nowrap;">Contactez-nous</a>
                  </li>
              </ul>

              

           <!-- User or Login -->
           <div class="navbar-text user-info">
                  <?php if (isset($_SESSION['user_id'])): ?>
                      <i class="fas fa-user" style="font-size: 0.9rem;"></i>
                      <?php
                      // Display the user's name from session
                      $username = $_SESSION['user_nom'] ?? 'Utilisateur';
                      echo htmlspecialchars($username);
                      ?>
                      <a href="?action=logout" class="nav-link logout-btn">
                          <i class="fas fa-sign-out-alt"></i> Déconnexion
                      </a>
                  <?php else: ?>
                      <a href="connexion.php" class="nav-link">Se connecter</a>
                  <?php endif; ?>
              
            
          </div>
      </div>
  </nav>
  
  <style>
      /* Ajustements pour le groupe de liens */
      @media (min-width: 992px) {
          .navbar-nav .nav-item[style*="inline-flex"] {
              display: inline-flex !important;
              align-items: center;
          }
          
          .navbar-brand {
              position: relative;
              left: -30px;
          }
          
          #ftco-nav {
              width: calc(100% - 100px);
          }
      }
      
      /* Version mobile */
      @media (max-width: 991px) {
          .navbar-nav .nav-item[style*="inline-flex"] {
              display: block !important;
          }
          
          .navbar-nav .nav-item[style*="inline-flex"] span {
              display: none;
          }
      }
  </style>
    
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact <i class="ion-ios-arrow-forward active"></i></span></p>
            <h1 class="mb-3 bread">Contactez-nous</h1>
          </div>
        </div>
      </div>
    </section>

    <section class="Contact-section">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
          
          <div class="row gy-4"><!-- Assurez-vous que col-lg-4 et col-lg-8 sont bien dans la même row -->
              
              <!-- Colonne gauche : Infos de contact -->
              <div class="col-lg-4">
                  <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="300">
                      <i class="bi bi-geo-alt flex-shrink-0"></i>
                      <div>
                          <h3>Adresse</h3>
                          <p>Ebène, Maurice</p>
                      </div>
                  </div><!-- End Info Item -->
  
                  <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="400">
                      <i class="bi bi-telephone flex-shrink-0"></i>
                      <div>
                          <h3>Appelez-nous</h3>
                          <p><a href="tel:+23070110033"> Jean Dubois (+230 70110033)</a></p>
                      </div>
                  </div><!-- End Info Item -->
  
                  <div class="info-item d-flex" data-aos="fade-up" data-aos-delay="500">
                      <i class="bi bi-envelope flex-shrink-0"></i>
                      <div>
                          <h3>Email</h3>
                          <p><a href="mailto:infoSuperCar@gmail.com">infoSuperCar@gmail.com</a></p>
                      </div>
                  </div><!-- End Info Item -->
              </div><!-- End Colonne Infos -->
  
              <!-- Colonne droite : Formulaire -->
              <div class="col-lg-8">
                <form id="contactForm" action="contact.php" method="POST" class="bg-light p-5 contact-form">
                      <div class="form-group">
                          <input type="text" class="form-control" name="nom" placeholder="Nom" required>
                      </div>
                      <div class="form-group">
                          <input type="email" class="form-control" name="email" placeholder="Email" required>
                      </div>
                      <div class="form-group">
                          <input type="text" class="form-control" name="sujet" placeholder="Sujet">
                      </div>
                      <div class="form-group">
                          <textarea name="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                      </div>
                      <div class="form-group">
                          <input type="submit" value="Envoyer" class="btn btn-primary py-3 px-5">
                      </div>
                  </form>
                  <div id="messageEnvoye" style="display:none; color: green; text-align: center; margin-top: 120px; font-size: 45px;">
                    Message envoyé avec succès !
                </div>
                </div>

        <script>
          document.getElementById("contactForm").addEventListener("submit", function(event) {
            event.preventDefault(); // Empêche le rechargement de la page
          
            let formData = new FormData(this);
          
            fetch("contact.php", {
              method: "POST",
              body: formData
            })
            .then(response => response.text())
            .then(data => {
              document.getElementById("contactForm").style.display = "none";
              document.getElementById("contactForm").reset();
              document.getElementById("messageEnvoye").style.display = "block";
            })
            .catch(error => console.error("Erreur :", error));
          });
          </script>
  

  
          </div><!-- End Row -->
      
      </div><!-- End Container -->
  </section>
  <div class="col-md-12 text-center">
  <div class="mb-4" data-aos="fade-up" data-aos-delay="200">
    <h4>Localisation</h4>
    <!--<iframe style="border:0; width: 100%; height: 270px;" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d48389.78314118045!2d-74.006138!3d40.710059!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a22a3bda30d%3A0xb89d1fe6bc499443!2sDowntown%20Conference%20Center!5e0!3m2!1sen!2sus!4v1676961268712!5m2!1sen!2sus" frameborder="0" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>-->
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3743.3006031008176!2d57.4867236750091!3d-20.246364181214368!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x217c5b1ef2170f63%3A0xd1a78020fc096491!2sMCCI%20BUSINESS%20SCHOOL%20(Mauritius%20Chamber%20of%20Commerce%20and%20Industry)!5e0!3m2!1sfr!2smu!4v1733312722116!5m2!1sfr!2smu" width="90%" height="400" style="border:0;;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
  </div><!-- End Google Maps -->
</div>

</main>

<<footer style="
background: linear-gradient(135deg, #247eec, #12906c, #2d73ed);
color: white;
padding: 1.5rem 0;
text-align: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
position: relative;
margin-top: 3rem;
box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
">
<div style="
	max-width: 1200px;
	margin: 0 auto;
	padding: 0 20px;
">
	<p style="
		margin: 0;
		font-size: 1.1rem;
		letter-spacing: 1px;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 10px;
		flex-wrap: wrap;
	">
		<span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>By Student MCCI</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>SIO</span>
	</p>
	
	<div style="
		margin-top: 1rem;
		display: flex;
		justify-content: center;
		gap: 1.5rem;
	">
		<a href="contacts.php" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-envelope"></i> Contact
		</a>
		<a href="confidentialité.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-shield-alt"></i> Confidentialité
		</a>
		<a href="Mention.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-file-alt"></i> Mentions légales
		</a>
	</div>
</div>
</footer>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>