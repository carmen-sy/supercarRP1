<?php
session_start();
session_destroy();

// Supprimer les cookies
setcookie("user_id", "", time() - 3600, "/");
setcookie("user_nom", "", time() - 3600, "/");

header("Location: connexion.php");
exit();
;
?>
