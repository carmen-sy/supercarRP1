<?php
ini_set('session.gc_maxlifetime', 7200);
session_set_cookie_params(7200);
session_start();

$host = "localhost";
$login = "root";
$pass = "";
$dbname = "supercar"; 

$conn = new mysqli($host, $login, $pass, $dbname);
if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

$successMessage = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Nom = $_POST["nom"] ?? null;
    $Prenom = $_POST["prenom"] ?? null;
    $Email = $_POST["email"] ?? null;
    $Ville = $_POST["ville"] ?? null;
    $password = $_POST["password"] ?? null;

    if (!$Nom || !$Prenom || !$Email || !$Ville || !$password) {
        die("Erreur : Veuillez remplir tous les champs.");
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO inscription (nom, prenom, email, ville, password) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $Nom, $Prenom, $Email, $Ville, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['prenom'] = $Prenom;
        $successMessage = "Merci de vous être inscrit sur <strong>Supercar</strong> <br><a href='connexion.php'>Connectez-vous ici</a>";
    } else {
        $successMessage = "Erreur : " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bienvenue sur Supercar</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:rgba(96, 97, 100, 0.45);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .message-box {
            background-color: white;
            padding: 50px 60px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 700px;
        }
        h1 {
            font-size: 36px;
            color: #021638cc;
            margin-bottom: 20px;
        }
        .message-box p {
            font-size: 18px;
            color: #333;
        }
        .message-box a {
            display: inline-block;
            margin-top: 20px;
            background-color:rgba(1, 4, 60, 0.91);
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body, html {
            height: 100%;
            font-family: Arial, sans-serif;
        }

        /* Vidéo de fond */
        .background-video {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            object-fit: cover;
            z-index: -1;
        }

        /* Boîte de message */
        .message-box {
            background-color: rgba(255, 255, 255, 0.9);
            padding: 50px 60px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 700px;
        }

        /* Centrage total */
        .content-wrapper {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h1 {
            font-size: 36px;
            color: #021638cc;
            margin-bottom: 20px;
        }

        .message-box p {
            font-size: 18px;
            color: #333;
        }

        .message-box a {
            display: inline-block;
            margin-top: 20px;
            background-color: rgba(1, 4, 60, 0.91);
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }
    </style>
</head>
<body>

  <!-- Vidéo de fond -->
  <video autoplay muted loop class="background-video">
        <source src="video/car on index.mp4" type="video/mp4">
        Votre navigateur ne supporte pas la lecture de vidéos HTML5.
    </video>

    <?php if ($successMessage && isset($_SESSION['prenom'])): ?>
        <div class="message-box">
            <h1>Bienvenue, <?= htmlspecialchars($_SESSION['prenom']) ?> !</h1>
            <p><?= $successMessage ?></p>
        </div>
    <?php endif; ?>
</body>
</html>
