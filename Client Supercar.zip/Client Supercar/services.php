<?php
session_start();

// Handle logout action
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Destroy session
    session_unset();
    session_destroy();
    // Clear cookies
    setcookie('user_id', '', time() - 3600, '/');
    setcookie('user_nom', '', time() - 3600, '/');
    // Redirect to Acceuil.php
    header("Location: Acceuil.php");
    exit();
}

// Récupérer la session depuis les cookies si elle n'existe pas
if (!isset($_SESSION["user_id"]) && isset($_COOKIE["user_id"])) {
    $_SESSION["user_id"] = $_COOKIE["user_id"];
    $_SESSION["user_nom"] = $_COOKIE["user_nom"];
}
?>

<!DOCTYPE html>
<html lang="fr">
  <head>
    <title>Services</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">

    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container-fluid px-0">


      
          <!-- Logo à gauche -->
          <a class="navbar-brand ml-lg-5 ml-3" href="index.html" style="margin-right: -50px;">
              Super<span>car</span>
          </a>
          
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
              <span class="oi oi-menu"></span> Menu
          </button>
  
          <div class="collapse navbar-collapse" id="ftco-nav">


              <!-- Menu centré -->
              <ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
                  <li class="nav-item "><a href="Acceuil.php" class="nav-link">Accueil</a></li>
                  <li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
                  <li class="nav-item active"><a href="services.php" class="nav-link">Services</a></li>


                  
                  <!-- Groupe Demande d'essai + Contact -->
                  <li class="nav-item" style="display: inline-flex;">
                      <a href="demande.php" class="nav-link" style="white-space: nowrap;">Demande d'essai</a>
                      <span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
                      <a href="contacts.php" class="nav-link" style="white-space: nowrap;">Contactez-nous</a>
                  </li>
              </ul>

              

           <!-- User or Login -->
           <div class="navbar-text user-info">
                  <?php if (isset($_SESSION['user_id'])): ?>
                      <i class="fas fa-user" style="font-size: 0.9rem;"></i>
                      <?php
                      // Display the user's name from session
                      $username = $_SESSION['user_nom'] ?? 'Utilisateur';
                      echo htmlspecialchars($username);
                      ?>
                      <a href="?action=logout" class="nav-link logout-btn">
                          <i class="fas fa-sign-out-alt"></i> Déconnexion
                      </a>
                  <?php else: ?>
                      <a href="connexion.php" class="nav-link">Se connecter</a>
                  <?php endif; ?>
              
            
          </div>
      </div>
  </nav>
  
  <style>
      /* Ajustements pour le groupe de liens */
      @media (min-width: 992px) {
          .navbar-nav .nav-item[style*="inline-flex"] {
              display: inline-flex !important;
              align-items: center;
          }
          
          .navbar-brand {
              position: relative;
              left: -30px;
          }
          
          #ftco-nav {
              width: calc(100% - 100px);
          }
      }
      
      /* Version mobile */
      @media (max-width: 991px) {
          .navbar-nav .nav-item[style*="inline-flex"] {
              display: block !important;
          }
          
          .navbar-nav .nav-item[style*="inline-flex"] span {
              display: none;
          }
      }
  </style>
    
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/bg_3.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> <span>Services <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Nos Offres de Services</h1>
          </div>
        </div>
      </div>
    </section>

    <section class="ftco-section">
			<div class="container">
				<div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
          	<span class="subheading">Nos Services</span>
            <h2 class="mb-3">Votre voiture mérite le meilleur ! Offrez-lui</h2>
          </div>
        </div>
				<div class="row">
					<div class="col-md-3">
						<div class="services services-2 w-100 text-center">
            	<div>
                <a href="services/maintenance.php"class="icon d-flex align-items-center justify-content-center">
                <i class="bi bi-tools"style="font-size: 60px; color:#fdfefe;"></i>
                </a>
              </div>
              <div class="text w-100">
                <h3 class="heading mb-2">Maintenance de voiture</h3>
                <p> Un entretien proactif est essentiel pour profiter d'un véhicule fiable et économique à long terme.</p>
              </div>
            </div>
					</div>
					<div class="col-md-3">
						<div class="services services-2 w-100 text-center">
            	<div>
                <a href="services/accessoires.php"class="icon d-flex align-items-center justify-content-center">
                <i class="bi bi-cart"style="font-size: 60px; color:#fdfefe;"></i>
                </a>
              </div>
                <div class="text w-100">
                <h3 class="heading mb-2"> Vente d'Accessoires </h3>
                <p>Découvrez notre large sélection d'accessoires de voiture de qualité pour améliorer le confort, la sécurité et les performances de votre véhicule..</p>
              </div>
            </div>
					</div>
					<div class="col-md-3">
						<div class="services services-2 w-100 text-center">
            	<div>
              <a href="services/pieces.php" class="icon d-flex align-items-center justify-content-center"> 
                <i class="bi bi-gear"style="font-size: 60px; color:#fdfefe;"></i>
              </a>
              </div>
                <div class="text w-100">
                <h3 class="heading mb-2"> Pièces de rechange</h3>
                <p>Trouvez des pièces détachées de qualité pour tous types de véhicules, pour assurer leur performance et leur longévité</p>
              </div>
            </div>
					</div>
					<div class="col-md-3">
						<div class="services services-2 w-100 text-center">
              <div>
                 <a href="services/conseil.php"class="icon d-flex align-items-center justify-content-center">
                 <i class="bi bi-person-check"style="font-size:60px;color:#fdfefe;"></i>
                 </a>
                </div>
            	<div class="text w-100">
                <h3 class="heading mb-2">Conseils et expertise</h3>
                <p>Bénéficiez de notre expertise pour des conseils personnalisés, vous aidant à entretenir et réparer votre véhicule en toute confiance</p>
              </div>
            </div>
					</div>
				</div>
			</div>
		</section>

    <footer style="
background: linear-gradient(135deg, #021638cc, #12906c, #021638cc);
color: white;
padding: 1.5rem 0;
text-align: center;
font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
position: relative;
margin-top: 3rem;
box-shadow: 0 -5px 15px rgba(0,0,0,0.1);
">
<div style="
	max-width: 1200px;
	margin: 0 auto;
	padding: 0 20px;
">
	<p style="
		margin: 0;
		font-size: 1.1rem;
		letter-spacing: 1px;
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 10px;
		flex-wrap: wrap;
	">
		<span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>By Student MCCI</span>
		<span style="color: rgba(255,255,255,0.8);">|</span>
		<span>SIO</span>
	</p>
	
	<div style="
		margin-top: 1rem;
		display: flex;
		justify-content: center;
		gap: 1.5rem;
	">
		<a href="contacts.php" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-envelope"></i> Contact
		</a>
		<a href="confidentialité.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-shield-alt"></i> Confidentialité
		</a>
		<a href="Mention.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-file-alt"></i> Mentions légales
		</a>
	</div>
</div>
</footer>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>