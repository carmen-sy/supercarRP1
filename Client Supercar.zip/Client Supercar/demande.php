<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    // Redirection vers la page de connexion si non connecté
    header("Location: connexion.php");
    exit();
}

// Récupérer le nom de l'utilisateur pour l'affichage dans le menu
$user_nom = $_SESSION['user_nom'] ?? 'Utilisateur';
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Demande</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container-fluid px-0">
			<!-- Logo à gauche -->
			<a class="navbar-brand ml-lg-5 ml-3" href="Acceuil.php" style="margin-right: -50px;">
				Super<span>car</span>
			</a>
			
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav">
				<span class="oi oi-menu"></span> Menu
			</button>
	
			<div class="collapse navbar-collapse" id="ftco-nav">
				<!-- Menu centré -->
				<ul class="navbar-nav mx-auto" style="max-width: 600px; width: 100%; display: flex; flex-wrap: nowrap;">
					<li class="nav-item"><a href="Acceuil.php" class="nav-link">Accueil</a></li>
					<li class="nav-item"><a href="car.php" class="nav-link">Voitures</a></li>
					<li class="nav-item"><a href="services.php" class="nav-link">Services</a></li>
					
					<!-- Groupe Demande d'essai + Contact -->
					<li class="nav-item" style="display: inline-flex;">
						<a href="demande.php" class="nav-item active" style="white-space: nowrap;">Demande d'essai</a>
						<span style="color: rgba(255,255,255,0.5); margin: 0 5px;"></span>
						<a href="contacts.php" class="nav-link" style="white-space: nowrap;">Contactez-nous</a>
					</li>
				</ul>
				
				<!-- User info comme sur la page d'accueil -->
				<div class="navbar-text user-info">
					<i class="fas fa-user" style="font-size: 0.9rem;"></i>
					<?php echo htmlspecialchars($user_nom); ?>
					<a href="Acceuil.php?action=logout" class="nav-link logout-btn">
						<i class="fas fa-sign-out-alt"></i> Déconnexion
					</a>
				</div>


	</nav>
	
	<style>
		@media (min-width: 992px) {
			.navbar-nav .nav-item[style*="inline-flex"] { display: inline-flex !important; align-items: center; }
			.navbar-brand { position: relative; left: -30px; }
			#ftco-nav { width: calc(100% - 100px); }
		}
		@media (max-width: 991px) {
			.navbar-nav .nav-item[style*="inline-flex"] { display: block !important; }
			.navbar-nav .nav-item[style*="inline-flex"] span { display: none; }
		}
	</style>

    <!-- Hero Section -->
    <section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url('images/cardealership.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-5">
          	<p class="breadcrumbs"><span class="mr-2"><a href="Acceuil.php">Accueil <i class="ion-ios-arrow-forward"></i></a></span> 
			<span>Demande d'essai <i class="ion-ios-arrow-forward"></i></span></p>
            <h1 class="mb-3 bread">Demande d'essai</h1>
          </div>
        </div>
      </div>
    </section>

    <!-- À propos / Introduction -->
    <section class="ftco-section ftco-about">
      <div class="container">
        <div class="row no-gutters">
          <div class="col-md-6 p-md-5 img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/conducteur.jpg);">
          </div>
          <div class="col-md-6 wrap-about ftco-animate">
            <div class="heading-section heading-section-white pl-md-5">
              <h2 class="mb-4">Demande d'essai</h2>
              <p>Vous avez trouvé votre voiture idéale ? Essayez la pour savoir si elle correspond à vos besoins !</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Formulaire de demande -->
    <section class="ftco-section ftco-no-pt bg-light">
    	<div class="container">
    		<div class="row no-gutters">
	  			<div class="col-md-4 d-flex align-items-center">
					<form action="Confirmation_demander.php" method="POST" class="request-form ftco-animate bg-primary">
						<h2>Choix de l'itinéraire</h2>
						
						<div class="form-group">
							<label for="nom" class="label">Nom</label>
							<input type="text" class="form-control" id="nom" name="nom" placeholder="Votre nom" required autocomplete="family-name">
						</div>
						
						<div class="form-group">
							<label for="prenom" class="label">Prénom</label>
							<input type="text" class="form-control" id="prenom" name="prenom" placeholder="Votre prénom" required autocomplete="given-name">
						</div>
						
						<div class="form-group">
							<label for="" class="label">Email</label>
							<input type="email" class="form-control" name="email" placeholder="Votre email" required>
						</div>
						
						<div class="form-group">
							<label for="" class="label">Lieu de récupération</label>
							<input type="text" class="form-control" name="lieurecup" placeholder="Ville, Quartier">
						</div>
						
						<div class="form-group">
							<label for="" class="label">Lieu de dépôt</label>
							<input type="text" class="form-control" name="lieudepot" placeholder="Ville, Quartier">
						</div>
						
						<label for="" class="label">Date</label>
						<div class="d-flex">
							<div class="form-group mr-2">
								<label for="" class="label">récupération</label>
								<input type="date" class="form-control" name="daterecup" placeholder="Date">
							</div>
							<div class="form-group ml-2">
								<label for="" class="label">Dépôt</label>
								<input type="date" class="form-control" name="datedepot" placeholder="Date">
							</div>
						</div>
						
						<div class="form-group">
							<label for="" class="label">Heure de récupération de la voiture</label>
							<input type="time" class="form-control" name="heurerecup" placeholder="Heure">
						</div>
						
						<input type="submit" value="Faire une demande" class="btn btn-secondary py-3 px-4">
					</form>
	  			</div>
	  			<div class="col-md-8 d-flex align-items-center">
	  				<div class="services-wrap rounded-right w-100">
	  					<h3 class="heading-section mb-4">Comment faire une demande d'essai ?</h3>
	  					<div class="row d-flex mb-4">
				          <div class="col-md-4 d-flex align-self-stretch ftco-animate">
				            <div class="services w-100 text-center">
				              	<div class="icon d-flex align-items-center justify-content-center">
									<a href="demande.php"><span class="flaticon-route"></span></a>
								</div>
				              	<div class="text w-100">
					                <h3 class="heading mb-2">Choisir le lieu et l'heure de récupération </h3>
				                </div>
				            </div>      
				          </div>
				          <div class="col-md-4 d-flex align-self-stretch ftco-animate">
							<div class="services w-100 text-center">
								<div class="icon d-flex align-items-center justify-content-center"> 
									<a href="car.php"><span class="flaticon-rent"></span></a>
								</div>
								<div class="text w-100">
									<h3 class="heading mb-2">Choisissez le modèle que vous voulez</h3>
								</div>
				            </div>      
				          </div>
				        </div>
	  				</div>
	  			</div>
	  		</div>
    	</div>
    </section>

    <!-- Footer -->
    <footer style="background: linear-gradient(135deg, #247eec, #12906c, #2d73ed); color: white; padding: 1.5rem 0; text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; position: relative; margin-top: 3rem; box-shadow: 0 -5px 15px rgba(0,0,0,0.1);">
	<div style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
		<p style="margin: 0; font-size: 1.1rem; letter-spacing: 1px; display: flex; justify-content: center; align-items: center; gap: 10px; flex-wrap: wrap;">
			<span style="font-weight: bold;">&copy; SUPERCAR 2024-2026</span>
			<span style="color: rgba(255,255,255,0.8);">|</span>
			<span>By Student MCCI</span>
			<span style="color: rgba(255,255,255,0.8);">|</span>
			<span>SIO</span>
		</p>
		<div style="margin-top: 1rem; display: flex; justify-content: center; gap: 1.5rem;">
		<a href="contacts.php" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-envelope"></i> Contact
		</a>
		<a href="confidentialité.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-shield-alt"></i> Confidentialité
		</a>
		<a href="Mention.html" style="color: white; text-decoration: none; transition: all 0.3s;">
			<i class="fas fa-file-alt"></i> Mentions légales
		</a>
		</div>
	</div>
    </footer>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/jquery.timepicker.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

</body>
</html>
